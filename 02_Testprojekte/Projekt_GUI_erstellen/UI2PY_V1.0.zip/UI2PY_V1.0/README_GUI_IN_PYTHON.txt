Verwendet wird der PyQt5 Designer um GUI zu erstellen. Diese wird im .ui Format ausgegeben


Folgender Code wandelt erstellte GUI von .ui zu .py um (siehe: https://stackoverflow.com/questions/13551316/error-converting-ui-file-to-py-file)

>> pyuic5 -x filename.ui > filename.py




