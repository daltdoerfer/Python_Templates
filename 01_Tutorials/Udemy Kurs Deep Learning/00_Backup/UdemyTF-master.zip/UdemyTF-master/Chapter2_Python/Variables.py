my_age = 26 # int
my_favourite_number = 1337.5 # float
my_name = "Jan Schaffranek" # str
am_i_cool = True # bool
am_i_uncool = False # bool
my_state = None # None
