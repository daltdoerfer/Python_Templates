# Benötigtes Wissen: Klassen und Vererbung

# Aufgabe:
# Erstelle eine Klasse, die dich als menschen
# darstellt, mit den Attributen Name, Nachname,
# Alter. Schreibe dann eine Funktion die dir die Daten 
# ausgibt. Erstelle dann eine Klasse Student die davon erbt
# und ebenfalls dazu Matr. Nr., Semester und Studiengang
# als Attribut hat.
#
# Zusatzaufgabe: Erstelle einige Objekte und iteriere über sie.
# Teste dann bei der Iteration, ob das Objekt ein Student ist
# oder nicht.