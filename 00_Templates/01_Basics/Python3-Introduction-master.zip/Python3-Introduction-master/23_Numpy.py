# Die Basics für Numpy Listen und Funktionen

import numpy as np
from numpy.linalg import eigvals

# data = [1.0, 2.0, 3.0]
# print(data)

# data2 = np.asarray(data, dtype=np.float64)
# print(data2)

# data3 = np.array([1.0, 2.0, 3.0], dtype=np.float64)
# print(data3)

# data4 = np.zeros(shape=(10), dtype=np.float64)
# print(data4)

# matrix = np.array([[1, 2, 3], [7, 1, 9], [4, 5, 3]], dtype=np.int8)
# print(matrix)

# matrix_transpose = np.transpose(matrix)
# print(matrix_transpose)

# matrix_invers = np.invert(matrix)
# print(matrix_invers)

# EW = np.linalg.eigvals(matrix)
# print(EW)

# EW, EV = np.linalg.eig(matrix)
# print(EW)
# print(EV)