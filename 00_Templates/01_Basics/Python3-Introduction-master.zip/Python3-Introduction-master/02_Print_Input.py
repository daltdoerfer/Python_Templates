# Daten ausgeben in der Konsole
zahl = 0.5
print('Die Zahl ist: ', zahl)

# Daten einlesen vom Benutzer
zahl = 0.0
zahl = input('Geben Sie eine Zahl ein!')
print('Die eingegebene Zahl ist: ', zahl)