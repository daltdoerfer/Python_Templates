# Dictionarys in Python {key: value}

tagebuch = {'montag': 'Doofer Tag', 'dienstag': 'War schon besser'}

tagebuch = {'montag': ['Schule doof', 'alles doof'], 
            'dienstag': ['Schule doof', 'ich bin aber cool']}

tagebuch = {'montag': {'morgens': 'dooof', 'mittags': 'doooooof', 'abends': 'okay'}, 
            'dienstag': ['Schule doof', 'ich bin aber cool']}

print(  tagebuch['montag']['morgens']  )