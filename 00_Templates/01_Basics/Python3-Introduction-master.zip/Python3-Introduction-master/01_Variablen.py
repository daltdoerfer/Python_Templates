# Variablen erstellen
path_to_save = "C:/Users/Jan/"

# Datentypen
zahl = 0.5
wahrheits_wert = False
print(type(wahrheits_wert))
# str, int, float, bool

# Neuzuweisungen
zahl = zahl ** zahl
print(zahl)

zahl = "Das ist kein Float"
print(type(zahl))

# Bool'sche ausdrücke
wahr = True
falsch = False

# Platzhalter?
zahl = 0
name = ""