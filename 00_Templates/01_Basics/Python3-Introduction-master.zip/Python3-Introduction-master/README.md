# Python3-Introduction

Python 3.6 Introduction for Beginners in Programming

# Goals:

Seperated in 23 parts and 5 practical exercises to gain knowledge in Python 3.6 coding.
Including the Modules Numpy, Matplotlib.
